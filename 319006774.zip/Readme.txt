Code was written on a Mac running OS 10.11.6. Please run on a similar environment. 

Executable instructions:
run with ./main

To compile:
g++ Main.cpp Graph.cpp -o main


Further Instructions:
in the main's main function there are options for either generating graphs and running the algorithms, or uploading an existing graph for testing. By default, the lines pertaining to uploading a graph are commented out. To change this, comment out the lines that generate the graps (i.e. g1.Generate(), g1.Print()) and uncomment out the lines pertaining to importing a graph (g2.GenerateTest(filename)).

All the graphs and results utilized in the report are included. 

